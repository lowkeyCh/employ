create definer = root@localhost trigger after_insert_user_graduate
    after insert
    on user
    for each row
begin

    IF "学生" = NEW.user_identity THEN
        insert into ccis.graduate(user_id)
        values (NEW.user_id);
    END IF;

    IF "企业" = NEW.user_identity THEN
    insert into ccis.enterprise(user_id)
    values (NEW.user_id);
    END IF;
end;

